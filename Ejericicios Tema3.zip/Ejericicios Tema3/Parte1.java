public class Parte1{
    public static void main(String[] args) {
        System.out.println(funcion(26, 23, 38));
    }

    public static int funcion(int nro1, int nro2, int nro3){
        return nro1 + nro2 + nro3;
    }
}